(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const storageKey = "proyecto_formativo_demo_v1";
  const pageNames = {
    inicio:["RESUMEN GENERAL","Panel de control","Bienvenido/a, Administrador Demo. Aquí tienes el resumen de tu negocio."],
    pedidos:["GESTIÓN COMERCIAL","Pedidos","Consulta y agrega pedidos de demostración."],
    clientes:["GESTIÓN COMERCIAL","Clientes","Administra los clientes de ejemplo."],
    productos:["GESTIÓN COMERCIAL","Productos","Consulta los productos disponibles para la venta."],
    proveedores:["GESTIÓN COMERCIAL","Proveedores","Administra los proveedores de ejemplo."],
    ingredientes:["INVENTARIO","Ingredientes","Revisa las cantidades y el estado de los ingredientes."],
    recetas:["INVENTARIO","Recetas","Consulta los ingredientes asociados a cada producto."],
    abastecimiento:["INVENTARIO","Abastecimiento","Registra entradas de inventario de demostración."],
    empleados:["ADMINISTRACIÓN","Empleados","Consulta los empleados de ejemplo."],
    gastos:["ADMINISTRACIÓN","Gastos","Consulta gastos ilustrativos del negocio."],
    finanzas:["ADMINISTRACIÓN","Finanzas","Resumen financiero basado en datos de demostración."],
    reportes:["ADMINISTRACIÓN","Reportes","Consulta un resumen de las operaciones de ejemplo."]
  };
  const initialData = {
    pedidos:[
      {id:"PED-0128",cliente:"María Fernández",fecha:"15/10/2026",total:125,estado:"Completado"},
      {id:"PED-0127",cliente:"Carlos Rojas",fecha:"15/10/2026",total:85,estado:"Completado"},
      {id:"PED-0126",cliente:"Ana Flores",fecha:"14/10/2026",total:150,estado:"Pendiente"},
      {id:"PED-0125",cliente:"Luis Mendoza",fecha:"14/10/2026",total:65,estado:"Completado"},
      {id:"PED-0124",cliente:"Sofía Vargas",fecha:"13/10/2026",total:95,estado:"Anulado"}
    ],
    clientes:[
      {nombre:"María Fernández",documento:"6892451",telefono:"70123456",direccion:"Centro",estado:"Activo"},
      {nombre:"Carlos Rojas",documento:"5831720",telefono:"71234567",direccion:"Villa Fátima",estado:"Activo"},
      {nombre:"Ana Flores",documento:"7214538",telefono:"76543210",direccion:"Miraflores",estado:"Activo"},
      {nombre:"Luis Mendoza",documento:"6498213",telefono:"72001122",direccion:"Sopocachi",estado:"Activo"}
    ],
    productos:[
      {nombre:"Hamburguesa clásica",categoria:"Hamburguesas",precio:30,stock:42,estado:"Disponible"},
      {nombre:"Hamburguesa doble",categoria:"Hamburguesas",precio:42,stock:24,estado:"Disponible"},
      {nombre:"Limonada",categoria:"Bebidas",precio:10,stock:35,estado:"Disponible"},
      {nombre:"Combo clásico",categoria:"Combos",precio:38,stock:18,estado:"Disponible"}
    ],
    proveedores:[
      {nombre:"Distribuidora Andina",contacto:"R. Salazar",telefono:"72001100",estado:"Activo"},
      {nombre:"Mercado Central",contacto:"M. Quispe",telefono:"72554433",estado:"Activo"},
      {nombre:"Lácteos del Valle",contacto:"J. Pérez",telefono:"70119922",estado:"Activo"}
    ],
    ingredientes:[
      {nombre:"Tomate",cantidad:"2,5 kg",minimo:"5 kg",estado:"Stock bajo"},
      {nombre:"Queso",cantidad:"1,2 kg",minimo:"4 kg",estado:"Crítico"},
      {nombre:"Carne molida",cantidad:"12 kg",minimo:"5 kg",estado:"Disponible"},
      {nombre:"Pan de hamburguesa",cantidad:"36 unidades",minimo:"15 unidades",estado:"Disponible"},
      {nombre:"Lechuga",cantidad:"6 unidades",minimo:"3 unidades",estado:"Disponible"}
    ],
    recetas:[
      {producto:"Hamburguesa clásica",ingredientes:"Pan, carne, tomate, lechuga",estado:"Registrada"},
      {producto:"Hamburguesa doble",ingredientes:"Pan, doble carne, queso, tomate",estado:"Registrada"},
      {producto:"Limonada",ingredientes:"Limón, agua, azúcar",estado:"Registrada"}
    ],
    abastecimiento:[
      {fecha:"14/10/2026",proveedor:"Mercado Central",detalle:"Verduras variadas",cantidad:"12 kg",total:180},
      {fecha:"12/10/2026",proveedor:"Lácteos del Valle",detalle:"Queso",cantidad:"5 kg",total:220}
    ],
    empleados:[
      {nombre:"Administrador Demo",cargo:"Supervisor",telefono:"70000001",estado:"Activo"},
      {nombre:"Daniel Choque",cargo:"Atención al cliente",telefono:"70000002",estado:"Activo"},
      {nombre:"Paola Mamani",cargo:"Cocina",telefono:"70000003",estado:"Activo"}
    ],
    gastos:[
      {fecha:"01/10/2026",concepto:"Electricidad",categoria:"Servicios",monto:280},
      {fecha:"03/10/2026",concepto:"Gas",categoria:"Servicios",monto:95},
      {fecha:"05/10/2026",concepto:"Flete de mercadería",categoria:"Transporte",monto:60}
    ]
  };
  const schemas = {
    pedidos:{title:"Nuevo pedido demo",fields:[["cliente","Cliente","text"],["total","Total (Bs)","number"],["estado","Estado","select",["Pendiente","Completado","Anulado"]]],columns:[["id","N.º pedido"],["cliente","Cliente"],["fecha","Fecha"],["total","Total"],["estado","Estado"]]},
    clientes:{title:"Nuevo cliente demo",fields:[["nombre","Nombre completo","text"],["documento","CI / NIT","text"],["telefono","Teléfono","tel"],["direccion","Dirección","text"]],columns:[["nombre","Cliente"],["documento","CI / NIT"],["telefono","Teléfono"],["direccion","Dirección"],["estado","Estado"]]},
    productos:{title:"Nuevo producto demo",fields:[["nombre","Nombre del producto","text"],["categoria","Categoría","text"],["precio","Precio (Bs)","number"],["stock","Stock","number"]],columns:[["nombre","Producto"],["categoria","Categoría"],["precio","Precio"],["stock","Stock"],["estado","Estado"]]},
    proveedores:{title:"Nuevo proveedor demo",fields:[["nombre","Nombre del proveedor","text"],["contacto","Persona de contacto","text"],["telefono","Teléfono","tel"]],columns:[["nombre","Proveedor"],["contacto","Contacto"],["telefono","Teléfono"],["estado","Estado"]]},
    ingredientes:{title:"Nuevo ingrediente demo",fields:[["nombre","Ingrediente","text"],["cantidad","Cantidad actual","text"],["minimo","Stock mínimo","text"]],columns:[["nombre","Ingrediente"],["cantidad","Cantidad actual"],["minimo","Stock mínimo"],["estado","Estado"]]},
    recetas:{title:"Nueva receta demo",fields:[["producto","Producto","text"],["ingredientes","Ingredientes","text"]],columns:[["producto","Producto"],["ingredientes","Ingredientes"],["estado","Estado"]]},
    abastecimiento:{title:"Nuevo abastecimiento demo",fields:[["proveedor","Proveedor","text"],["detalle","Detalle","text"],["cantidad","Cantidad","text"],["total","Total (Bs)","number"]],columns:[["fecha","Fecha"],["proveedor","Proveedor"],["detalle","Detalle"],["cantidad","Cantidad"],["total","Total"]]},
    empleados:{title:"Nuevo empleado demo",fields:[["nombre","Nombre completo","text"],["cargo","Cargo","text"],["telefono","Teléfono","tel"]],columns:[["nombre","Empleado"],["cargo","Cargo"],["telefono","Teléfono"],["estado","Estado"]]},
    gastos:{title:"Nuevo gasto demo",fields:[["concepto","Concepto","text"],["categoria","Categoría","text"],["monto","Monto (Bs)","number"]],columns:[["fecha","Fecha"],["concepto","Concepto"],["categoria","Categoría"],["monto","Monto"]]}
  };
  let data = loadData();
  let currentPage = "inicio";
  let toastTimer;

  function clone(obj){return JSON.parse(JSON.stringify(obj));}
  function loadData(){
    try {
      const saved = localStorage.getItem(storageKey);
      if(saved) return {...clone(initialData),...JSON.parse(saved)};
    } catch(e) {}
    return clone(initialData);
  }
  function saveData(){
    try { localStorage.setItem(storageKey, JSON.stringify(data)); }
    catch(e) { showToast("No se pudo guardar en este navegador."); }
  }
  function escapeHtml(value){
    return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  }
  function money(value){return "Bs "+Number(value||0).toLocaleString("es-BO",{minimumFractionDigits:2,maximumFractionDigits:2});}
  function dateToday(){return new Date().toLocaleDateString("es-BO",{day:"2-digit",month:"2-digit",year:"numeric"});}
  function statusClass(value){
    const v=String(value||"").toLowerCase();
    if(v.includes("complet")||v.includes("activ")||v.includes("dispon")||v.includes("registr")) return "badge-success";
    if(v.includes("bajo")||v.includes("pendiente")) return "badge-warning";
    if(v.includes("crít")||v.includes("crit")||v.includes("anulad")) return "badge-danger";
    return "";
  }
  function formatCell(key,value){
    if(key==="total"||key==="precio"||key==="monto") return `<span class="money">${money(value)}</span>`;
    if(key==="id") return `<span class="order-id">${escapeHtml(value)}</span>`;
    if(key==="estado") return `<span class="badge ${statusClass(value)}">${escapeHtml(value)}</span>`;
    return escapeHtml(value);
  }
  function renderRecentOrders(){
    const body=$("#recentOrders");
    body.innerHTML=data.pedidos.slice(0,4).map(o=>`<tr><td>${formatCell("id",o.id)}</td><td>${escapeHtml(o.cliente)}</td><td>${escapeHtml(o.fecha)}</td><td>${formatCell("total",o.total)}</td><td>${formatCell("estado",o.estado)}</td></tr>`).join("");
  }
  function renderModule(){
    const schema=schemas[currentPage];
    const rows=data[currentPage]||[];
    const query=($("#searchInput").value||"").trim().toLowerCase();
    const filtered=rows.filter(row=>Object.values(row).some(v=>String(v).toLowerCase().includes(query)));
    $("#moduleHeading").textContent=pageNames[currentPage][1];
    $("#moduleDescription").textContent=pageNames[currentPage][2];
    $("#moduleHead").innerHTML=`<tr>${schema.columns.map(c=>`<th>${escapeHtml(c[1])}</th>`).join("")}</tr>`;
    $("#moduleBody").innerHTML=filtered.length?filtered.map(row=>`<tr>${schema.columns.map(c=>`<td>${formatCell(c[0],row[c[0]]??"—")}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${schema.columns.length}" style="text-align:center;padding:28px;color:#999caf">No se encontraron registros.</td></tr>`;
    $("#tableCount").textContent=`Mostrando ${filtered.length} de ${rows.length} registros de ejemplo`;
    $("#moduleAdd").classList.toggle("hidden",!schemas[currentPage].fields);
  }
  function go(page){
    if(!pageNames[page]) return;
    currentPage=page;
    $$(".nav-item").forEach(btn=>btn.classList.toggle("active",btn.dataset.page===page));
    $("#breadcrumbPage").textContent=pageNames[page][1];
    $("#pageEyebrow").textContent=pageNames[page][0];
    $("#pageTitle").textContent=pageNames[page][1]==="Inicio"?"Panel de control":pageNames[page][1];
    $("#pageSubtitle").textContent=pageNames[page][2];
    $("#dashboardPage").classList.toggle("hidden",page!=="inicio");
    $("#modulePage").classList.toggle("hidden",page==="inicio");
    $("#primaryAction").innerHTML=page==="inicio"?"<span>＋</span> Nuevo pedido":`<span>＋</span> Agregar ${pageNames[page][1].toLowerCase().replace(/s$/,"")}`;

    $("#searchInput").value="";
    if(page!=="inicio") renderModule();
    closeSidebar();
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function openRecord(page){
    if(!schemas[page]){showToast("Este apartado es informativo en la demo.");return;}
    currentPage=page;
    const schema=schemas[page];
    $("#dialogTitle").textContent=schema.title;
    $("#formFields").innerHTML=schema.fields.map(([key,label,type,options])=>{
      if(type==="select") return `<label class="field-label">${escapeHtml(label)}<select name="${escapeHtml(key)}" required>${options.map(o=>`<option>${escapeHtml(o)}</option>`).join("")}</select></label>`;
      return `<label class="field-label">${escapeHtml(label)}<input name="${escapeHtml(key)}" type="${escapeHtml(type)}" ${type==="number"?'min="0" step="0.01"':''} required></label>`;
    }).join("");
    $("#recordDialog").showModal();
  }
  $("#recordForm").addEventListener("submit",event=>{
    const submitter=event.submitter;
    if(submitter && submitter.value==="cancel") return;
    event.preventDefault();
    if(!$("#recordForm").reportValidity()) return;
    const formData=new FormData($("#recordForm"));
    const record=Object.fromEntries(formData.entries());
    const page=currentPage;
    for(const [key] of schemas[page].fields){
      if(["total","precio","stock","monto"].includes(key)) record[key]=Number(record[key]||0);
    }
    if(page==="pedidos"){record.id="PED-DEMO-"+String(Date.now()).slice(-5);record.fecha=dateToday();}
    if(page==="abastecimiento"||page==="gastos") record.fecha=dateToday();
    if(["clientes","productos","proveedores","ingredientes","recetas","empleados"].includes(page)) record.estado=page==="ingredientes"?"Disponible":page==="recetas"?"Registrada":page==="productos"?"Disponible":"Activo";
    data[page].unshift(record);
    saveData();
    $("#recordDialog").close();
    if(currentPage!=="inicio") renderModule();
    renderRecentOrders();
    showToast("Registro de demostración agregado.");
  });
  function showToast(message){
    const toast=$("#toast");toast.textContent=message;toast.classList.add("show");
    clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2800);
  }
  function openSidebar(){$("#sidebar").classList.add("open");$("#scrim").classList.add("show");}
  function closeSidebar(){$("#sidebar").classList.remove("open");$("#scrim").classList.remove("show");}
  $$(".nav-item").forEach(btn=>btn.addEventListener("click",()=>go(btn.dataset.page)));
  $$("[data-go]").forEach(btn=>btn.addEventListener("click",()=>go(btn.dataset.go)));
  $("#openSidebar").addEventListener("click",openSidebar);
  $("#closeSidebar").addEventListener("click",closeSidebar);
  $("#scrim").addEventListener("click",closeSidebar);
  $("#primaryAction").addEventListener("click",()=>openRecord(currentPage==="inicio"?"pedidos":currentPage));
  $("#moduleAdd").addEventListener("click",()=>openRecord(currentPage));
  $("#searchInput").addEventListener("input",renderModule);
  $("#clearSearch").addEventListener("click",()=>{$("#searchInput").value="";renderModule();});
  $("#helpButton").addEventListener("click",()=>$("#infoDialog").showModal());
  $("#resetDemo").addEventListener("click",()=>{
    if(confirm("¿Restablecer todos los registros de demostración de este navegador?")){
      data=clone(initialData);saveData();renderRecentOrders();if(currentPage!=="inicio")renderModule();showToast("Datos de demostración restablecidos.");
    }
  });
  renderRecentOrders();
})();