# Proyecto Formativo — versión para GitHub Pages

Esta carpeta contiene una versión estática de demostración del panel de ventas.

## Archivos
- `index.html`: estructura y contenido del panel.
- `github.css`: estilos y diseño adaptable a móviles.
- `github.js`: navegación, tablas de ejemplo, búsqueda y formularios de demostración.

## Publicar en GitHub Pages
1. Abre el repositorio `proyecto_formativo-`.
2. Pulsa **Add file → Upload files**.
3. Sube `index.html`, `github.css` y `github.js` a la raíz del repositorio (el mismo nivel donde están tus archivos PHP).
4. Pulsa **Commit changes**.
5. Abre **Settings → Pages** y confirma que la fuente sea la rama `Principal` y la carpeta `/ (root)`.
6. Espera unos minutos y abre:
   `https://alejandro2005exe-byte.github.io/proyecto_formativo-/`

GitHub Pages buscará `index.html` para mostrar la página estática. No hace falta borrar `index.php`; la página estática usará `index.html` como entrada.

## Limitaciones
- GitHub Pages no ejecuta PHP ni se conecta directamente a MySQL.
- Los datos son ficticios y sirven para demostración.
- Los nuevos registros se guardan en el almacenamiento local del navegador; no se comparten entre equipos ni usuarios y pueden borrarse al limpiar los datos del navegador.
- No uses esta versión para registrar ventas reales ni información personal.
- El diseño utiliza Google Fonts cuando hay conexión a Internet; si no carga, se usarán fuentes alternativas del equipo.
